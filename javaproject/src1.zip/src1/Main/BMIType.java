package Main;

public enum BMIType {
    thin,
    normal,
    fat,
    veryfat
}
