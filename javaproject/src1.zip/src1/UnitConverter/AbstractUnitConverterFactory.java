package UnitConverter;

public abstract class AbstractUnitConverterFactory {
    public abstract AbstractUnitConverter CreateUnitConverter(int converterType);
}
