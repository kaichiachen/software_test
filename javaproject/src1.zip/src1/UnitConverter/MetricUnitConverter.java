package UnitConverter;

public class MetricUnitConverter extends AbstractUnitConverter {
    @Override
    public float convertHeightToMetric(float height) {
        return height;
    }

    @Override
    public float convertWeightToMetric(float weight) {
        return weight;
    }
}
