package UnitConverter;

public abstract class AbstractUnitConverter {
    public abstract float convertHeightToMetric(float height);
    public abstract float convertWeightToMetric(float weight);
}
